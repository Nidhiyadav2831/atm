# 🏦 ATM Machine Simulator

A modern, interactive ATM machine simulator built with HTML, CSS, and JavaScript. This project provides a realistic ATM experience with a beautiful user interface and comprehensive functionality.

## ✨ Features

### 🔐 Authentication
- Secure PIN-based authentication
- Support for multiple user accounts
- Session management with automatic logout

### 💰 Banking Operations
- **Balance Inquiry**: Check current account balance
- **Cash Withdrawal**: Withdraw money with transaction limits
- **Cash Deposit**: Deposit money with validation
- **Fund Transfer**: Transfer money between accounts
- **Mini Statement**: View recent transaction history

### 🎨 User Interface
- Modern, responsive design
- Realistic ATM machine appearance
- Interactive keypad for number input
- Smooth animations and transitions
- Error and success message handling
- Mobile-friendly responsive layout

### 🔒 Security Features
- Transaction limits (Withdrawal: $1000, Deposit: $10,000, Transfer: $5,000)
- Input validation and error handling
- Insufficient funds protection
- Duplicate transfer prevention

## 🚀 Getting Started

### Prerequisites
- A modern web browser (Chrome, Firefox, Safari, Edge)
- No additional software installation required

### Installation
1. Clone or download the project files
2. Open `index.html` in your web browser
3. Start using the ATM simulator!

### Running the Application
```bash
# Simply open the index.html file in your browser
# Or use a local server for better experience
python -m http.server 8000  # Python 3
# or
npx serve .                 # Node.js
```

## 👥 Sample User Accounts

The ATM comes with two pre-configured user accounts for testing:

### Account 1
- **PIN**: `1234`
- **Name**: John Doe
- **Balance**: $5,000.00
- **Account Number**: 1234567890

### Account 2
- **PIN**: `5678`
- **Name**: Jane Smith
- **Balance**: $7,500.00
- **Account Number**: 0987654321

## 🎯 How to Use

### 1. Authentication
- Enter your 4-digit PIN using the keypad or keyboard
- Click "Enter" or press Enter key to proceed
- Invalid PINs will show an error message

### 2. Main Menu
After successful authentication, you'll see the main menu with options:
- 💰 Check Balance
- 💸 Withdraw
- 💳 Deposit
- 🔄 Transfer
- 📋 Mini Statement
- 🚪 Logout

### 3. Transactions

#### Withdrawal
- Select "Withdraw" from the menu
- Enter amount manually or use quick amount buttons ($50, $100, $200, $500)
- Maximum withdrawal limit: $1,000
- Transaction will be processed immediately

#### Deposit
- Select "Deposit" from the menu
- Enter the amount to deposit
- Maximum deposit limit: $10,000
- Transaction will be processed immediately

#### Transfer
- Select "Transfer" from the menu
- Enter recipient's account number
- Enter transfer amount
- Maximum transfer limit: $5,000
- Cannot transfer to your own account

#### Mini Statement
- Select "Mini Statement" from the menu
- View your last 10 transactions
- Shows transaction type, amount, date, and time

### 4. Navigation
- Use "Back to Menu" to return to the main menu
- Use "Logout" to end your session
- All screens have smooth transitions

## 🛠️ Technical Details

### File Structure
```
atm-machine/
├── index.html          # Main HTML file
├── style.css           # CSS styling
├── script.js           # JavaScript functionality
└── README.md           # This file
```

### Technologies Used
- **HTML5**: Semantic markup and structure
- **CSS3**: Modern styling with gradients, animations, and responsive design
- **JavaScript (ES6+)**: Interactive functionality and state management
- **Google Fonts**: Roboto font family for better typography

### Key Features Implementation

#### State Management
- Global variables track current user, authentication status, and screen state
- Screen transitions are handled smoothly with show/hide logic

#### Input Handling
- Virtual keypad for number input
- Keyboard support for all operations
- Input validation and sanitization

#### Transaction Processing
- Real-time balance updates
- Transaction history tracking
- Error handling for edge cases

#### Responsive Design
- Mobile-first approach
- Flexible grid layouts
- Adaptive typography and spacing

## 🎨 Design Features

### Visual Elements
- **Color Scheme**: Dark theme with green terminal-style text
- **Gradients**: Modern gradient backgrounds for depth
- **Shadows**: Subtle shadows for 3D effect
- **Animations**: Smooth transitions and hover effects

### User Experience
- **Intuitive Navigation**: Clear menu structure
- **Visual Feedback**: Success/error messages with animations
- **Accessibility**: Keyboard navigation support
- **Responsive**: Works on all device sizes

## 🔧 Customization

### Adding New Users
To add new user accounts, modify the `users` array in `script.js`:

```javascript
const users = [
    // ... existing users
    {
        accountNumber: "1111111111",
        pin: "9999",
        name: "New User",
        balance: 1000.00,
        transactions: []
    }
];
```

### Modifying Transaction Limits
Update the limit values in the transaction functions:

```javascript
// In processWithdraw()
if (amount > 1000) { // Change this value
    showError("Maximum withdrawal limit is $1000");
    return;
}
```

### Styling Changes
- Modify `style.css` to change colors, fonts, or layout
- Update CSS variables for consistent theming
- Add new animations or transitions

## 🐛 Troubleshooting

### Common Issues

1. **ATM not loading**
   - Ensure all files are in the same directory
   - Check browser console for JavaScript errors
   - Try refreshing the page

2. **PIN not working**
   - Use the sample PINs: `1234` or `5678`
   - Ensure you're entering exactly 4 digits
   - Check for any input field focus issues

3. **Transactions not processing**
   - Verify you have sufficient funds
   - Check transaction limits
   - Ensure all required fields are filled

### Browser Compatibility
- Chrome 60+
- Firefox 55+
- Safari 12+
- Edge 79+

## 📝 License

This project is open source and available under the [MIT License](LICENSE).

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

### Development Setup
1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📞 Support

If you encounter any issues or have questions:
1. Check the troubleshooting section above
2. Review the browser console for errors
3. Ensure all files are properly loaded

## 🎉 Acknowledgments

- Inspired by real ATM interfaces
- Built with modern web technologies
- Designed for educational and demonstration purposes

---

**Note**: This is a simulation for educational purposes. It does not connect to real banking systems or process actual financial transactions. 