# 🏦 ATM Machine - Data Structures & Algorithms Analysis

## 📊 Overview
This document analyzes the Data Structures and Algorithms (DSA) concepts implemented in the ATM Machine simulator. The project demonstrates various fundamental DSA concepts in a real-world banking application.

---

## 🏗️ **DATA STRUCTURES USED**

### 1. **Arrays** 📋

#### **User Data Array**
```javascript
const users = [
    {
        accountNumber: "1234567890",
        pin: "1234",
        name: "John Doe",
        balance: 5000.00,
        transactions: []
    },
    {
        accountNumber: "0987654321",
        pin: "5678",
        name: "Jane Smith",
        balance: 7500.00,
        transactions: []
    }
];
```
**Usage**: Stores multiple user objects in a linear data structure
**DSA Concept**: Linear Data Structure, Index-based access

#### **Transaction History Arrays**
```javascript
users[0].transactions = [
    { type: 'Deposit', amount: 1000, date: new Date('2024-01-15'), balance: 5000 },
    { type: 'Withdrawal', amount: -200, date: new Date('2024-01-20'), balance: 4800 },
    // ... more transactions
];
```
**Usage**: Stores transaction history for each user
**DSA Concept**: Dynamic Array, Sequential Data Storage

#### **Screen Management Array**
```javascript
const screens = ['welcomeScreen', 'menuScreen', 'balanceScreen', 'withdrawScreen', 'depositScreen', 'transferScreen', 'statementScreen'];
```
**Usage**: Manages multiple screen elements
**DSA Concept**: Array Iteration, Element Manipulation

### 2. **Objects (Hash Maps/Dictionaries)** 🗂️

#### **User Object Structure**
```javascript
{
    accountNumber: "1234567890",  // Key-Value Pair
    pin: "1234",                  // Key-Value Pair
    name: "John Doe",             // Key-Value Pair
    balance: 5000.00,             // Key-Value Pair
    transactions: []              // Key-Value Pair (Array)
}
```
**Usage**: Represents user data with key-value pairs
**DSA Concept**: Hash Map, Associative Array, Object-Oriented Data Structure

#### **Transaction Object Structure**
```javascript
{
    type: 'Deposit',              // Key-Value Pair
    amount: 1000,                 // Key-Value Pair
    date: new Date('2024-01-15'), // Key-Value Pair
    balance: 5000                 // Key-Value Pair
}
```
**Usage**: Represents individual transaction data
**DSA Concept**: Structured Data, Object Composition

#### **Screen Mapping Object**
```javascript
const screenMap = {
    'welcome': 'welcomeScreen',
    'menu': 'menuScreen',
    'balance': 'balanceScreen',
    'withdraw': 'withdrawScreen',
    'deposit': 'depositScreen',
    'transfer': 'transferScreen',
    'statement': 'statementScreen'
};
```
**Usage**: Maps screen states to DOM elements
**DSA Concept**: Hash Table, Key-Value Mapping

### 3. **Strings** 📝

#### **PIN Validation**
```javascript
if (pin.length !== 4) {
    showError("Please enter a 4-digit PIN");
    return;
}
```
**Usage**: String length validation
**DSA Concept**: String Manipulation, Length Property

#### **Input Validation**
```javascript
if (/^[0-9]$/.test(event.key)) {
    // Handle numeric input
}
```
**Usage**: Regular expression pattern matching
**DSA Concept**: String Pattern Matching, Regular Expressions

---

## 🔍 **ALGORITHMS IMPLEMENTED**

### 1. **Search Algorithms** 🔍

#### **Linear Search (User Authentication)**
```javascript
const user = users.find(u => u.pin === pin);
```
**Algorithm**: Linear Search
**Time Complexity**: O(n) where n = number of users
**Usage**: Finding user by PIN during authentication
**DSA Concept**: Sequential Search, Array Traversal

#### **Linear Search (Recipient Validation)**
```javascript
const recipient = users.find(u => u.accountNumber === recipientAccount);
```
**Algorithm**: Linear Search
**Time Complexity**: O(n) where n = number of users
**Usage**: Finding recipient account for transfers
**DSA Concept**: Array Search, Element Comparison

### 2. **Array Manipulation Algorithms** 📊

#### **Array Slice and Reverse (Mini Statement)**
```javascript
const recentTransactions = currentUser.transactions.slice(-10).reverse();
```
**Algorithm**: Array Slicing + Reversal
**Time Complexity**: O(k) where k = number of elements to slice
**Usage**: Getting last 10 transactions in reverse order
**DSA Concept**: Array Manipulation, Subarray Operations

#### **Array Iteration (Screen Management)**
```javascript
screens.forEach(screenId => {
    document.getElementById(screenId).style.display = 'none';
});
```
**Algorithm**: Array Traversal
**Time Complexity**: O(n) where n = number of screens
**Usage**: Hiding all screens during navigation
**DSA Concept**: Array Iteration, Element Manipulation

#### **Array Iteration (Input Clearing)**
```javascript
inputs.forEach(inputId => {
    const input = document.getElementById(inputId);
    if (input) {
        input.value = '';
    }
});
```
**Algorithm**: Array Traversal with Conditional Logic
**Time Complexity**: O(n) where n = number of inputs
**Usage**: Clearing all input fields
**DSA Concept**: Array Processing, Conditional Operations

### 3. **String Manipulation Algorithms** 📝

#### **String Length Validation**
```javascript
if (pin.length !== 4) {
    // Error handling
}
```
**Algorithm**: String Length Check
**Time Complexity**: O(1)
**Usage**: PIN validation
**DSA Concept**: String Properties, Validation

#### **String Concatenation**
```javascript
targetInput.value += value;
```
**Algorithm**: String Concatenation
**Time Complexity**: O(1) for single character
**Usage**: Building input values
**DSA Concept**: String Operations, Dynamic String Building

#### **String Slicing (Backspace)**
```javascript
targetInput.value = targetInput.value.slice(0, -1);
```
**Algorithm**: String Slicing
**Time Complexity**: O(n) where n = string length
**Usage**: Removing last character from input
**DSA Concept**: String Manipulation, Substring Operations

### 4. **State Management Algorithms** 🎛️

#### **State Machine (Screen Navigation)**
```javascript
function getTargetInput() {
    switch (currentScreen) {
        case 'welcome':
            return document.getElementById('pinInput');
        case 'withdraw':
            return document.getElementById('withdrawAmount');
        case 'deposit':
            return document.getElementById('depositAmount');
        // ... more cases
    }
}
```
**Algorithm**: State Machine Pattern
**Time Complexity**: O(1)
**Usage**: Determining which input to target based on current screen
**DSA Concept**: State Management, Switch Statement, Conditional Logic

#### **Event-Driven State Changes**
```javascript
document.addEventListener('keydown', function(event) {
    if (event.key === 'Enter') {
        switch (currentScreen) {
            case 'welcome':
                enterPin();
                break;
            case 'withdraw':
                processWithdraw();
                break;
            // ... more cases
        }
    }
});
```
**Algorithm**: Event-Driven State Machine
**Time Complexity**: O(1)
**Usage**: Handling user input based on current application state
**DSA Concept**: Event Handling, State Transitions

### 5. **Validation Algorithms** ✅

#### **Input Validation Chain**
```javascript
function processWithdraw() {
    const amount = parseFloat(amountInput.value);
    
    if (!amount || amount <= 0) {
        showError("Please enter a valid amount");
        return;
    }
    
    if (amount > currentUser.balance) {
        showError("Insufficient funds");
        return;
    }
    
    if (amount > 1000) {
        showError("Maximum withdrawal limit is $1000");
        return;
    }
    
    // Process transaction
}
```
**Algorithm**: Validation Chain with Early Exit
**Time Complexity**: O(1)
**Usage**: Multiple validation checks before processing
**DSA Concept**: Conditional Logic, Early Exit Pattern, Input Validation

#### **Type Conversion and Validation**
```javascript
const amount = parseFloat(amountInput.value);
if (!amount || amount <= 0) {
    // Error handling
}
```
**Algorithm**: Type Conversion with Validation
**Time Complexity**: O(1)
**Usage**: Converting string input to numeric value
**DSA Concept**: Type Conversion, Data Validation

---

## 🎯 **ADVANCED DSA CONCEPTS**

### 1. **Queue-like Behavior (Transaction History)**
```javascript
// Adding new transaction (enqueue)
currentUser.transactions.push({
    type: type,
    amount: amount,
    date: new Date(),
    balance: currentUser.balance
});

// Getting recent transactions (dequeue-like)
const recentTransactions = currentUser.transactions.slice(-10).reverse();
```
**DSA Concept**: Queue Operations, FIFO (First In, First Out) with LIFO display

### 2. **Stack-like Behavior (Screen Navigation)**
```javascript
// Push operation (navigate to new screen)
function showMenu() {
    hideAllScreens();
    document.getElementById('menuScreen').style.display = 'block';
    currentScreen = 'menu';
}

// Pop operation (go back to menu)
function backToMenu() {
    showMenu();
}
```
**DSA Concept**: Stack Operations, LIFO (Last In, First Out) navigation

### 3. **Hash Table Operations**
```javascript
// Hash table lookup
const screenId = screenMap[currentScreen];
return screenId ? document.getElementById(screenId) : null;
```
**DSA Concept**: Hash Table Access, Key-Value Retrieval

### 4. **Tree-like DOM Manipulation**
```javascript
// DOM tree traversal
const currentScreenElement = getCurrentScreenElement();
if (currentScreenElement) {
    currentScreenElement.insertBefore(errorDiv, currentScreenElement.firstChild);
}
```
**DSA Concept**: Tree Traversal, DOM Manipulation

---

## 📈 **TIME & SPACE COMPLEXITY ANALYSIS**

### **Time Complexity**
- **User Authentication**: O(n) - Linear search through users
- **Transaction Processing**: O(1) - Direct object manipulation
- **Screen Navigation**: O(1) - Hash table lookup
- **Input Validation**: O(1) - Simple conditional checks
- **Transaction History**: O(k) - Array slicing where k = number of transactions

### **Space Complexity**
- **User Data**: O(n) - n users with transaction history
- **Transaction History**: O(t) - t transactions per user
- **Screen State**: O(1) - Constant state variables
- **Input Processing**: O(1) - Constant input buffers

---

## 🎓 **LEARNING OBJECTIVES ACHIEVED**

### **Data Structures**
✅ Arrays and Array Operations  
✅ Objects and Hash Maps  
✅ Strings and String Manipulation  
✅ Queues and Stacks (conceptual)  
✅ Trees (DOM manipulation)  

### **Algorithms**
✅ Linear Search  
✅ Array Traversal and Manipulation  
✅ String Operations  
✅ State Machine Pattern  
✅ Validation Algorithms  
✅ Event-Driven Programming  

### **Advanced Concepts**
✅ Time and Space Complexity  
✅ Algorithm Optimization  
✅ Data Structure Selection  
✅ Real-world Application of DSA  

---

## 🚀 **OPTIMIZATION OPPORTUNITIES**

### **Current Implementation**
- Linear search for user authentication (O(n))
- Array-based transaction storage
- Simple state management

### **Potential Improvements**
- **Binary Search Tree** for user lookup (O(log n))
- **Hash Table** for O(1) user authentication
- **Linked List** for transaction history
- **Priority Queue** for transaction processing
- **Graph** for complex banking relationships

---

## 📚 **CONCLUSION**

The ATM Machine project successfully demonstrates fundamental DSA concepts in a practical, real-world application. It showcases:

1. **Data Structure Selection**: Appropriate use of arrays, objects, and strings
2. **Algorithm Implementation**: Search, validation, and state management algorithms
3. **Complexity Awareness**: Understanding of time and space complexity
4. **Practical Application**: Real-world problem solving with DSA concepts

This project serves as an excellent example of how DSA concepts are applied in modern web applications and provides a foundation for understanding more complex algorithms and data structures. 